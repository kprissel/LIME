%% LIME User Input File - Prissel, Olive, & Krawczynski
%This is the file from which to run the LIME code and adjust any user-specified parameters
%Last updated April 12 2021

%% INPUT FILE(S)
%Input file can be .xlsx or .txt, see included "Inputs" folder for examples and TEMPLATE.xlsx
filename = {'Inputs/J047.xlsx'}; %file path for data input file(s)

%% USER-SPECIFIED PARAMETERS
pct_err_bulk = 1; %percent uncertainty in bulk composition if not specified in data file
output_yn = 1; %whether or not to output results to folder, 1 = yes, 0 = no
plot_cvg = 1; %set=1 to visually assess convergence of algorithm

%% Run the code for each input file
for f=1:length(filename)
    %When running more than 1 input file, clear results from previous loop
    clearvars -except f filename pct_err_bulk output_yn plot_cvg
    
    %% ADDITIONAL PARAMETERS (that most likely need not be changed)
    yn_iterate_on_endmembers=0; % iterate endmember compositions (1=yes, 0=no)
    errortype = 1; %set equal to 1 (standard error) or 2 (standard error of the mean)
    NEWT.error_measure = [25 75]; % =1 means proportion errors are 1-sigma equivalent. If a vector of 2 values is specified, these will be used as percentiles of the posterior distribution.
    Ndrawdobs=1000; % number of bulk compositions to be drawn to estimate uncertainties
    NEWT.Nit=100; % number of iterations of the Newton method
    NEWT.step=0.001; % elementary step in ilr-model space for finite difference approx of Jacobian
    NEWT.mu=0.3; % damping term in Newton iterations
    NEWT.sig_am0=1; % uncertainty on a-priori phase composition in ilr space
    NEWT.Ndraw=80000; % number of samples to draw from posterior distribution

    %% RUN THE MAIN SCRIPT
    main_script
end