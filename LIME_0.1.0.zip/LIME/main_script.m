%% LIME code main script - Prissel, Olive, & Krawczynski
%Last updated June 28 2023

%% Load data and prepare for calculation using preplime.m function
[dobs, mnr, uc, phase_label] = preplime(filename{f}, pct_err_bulk);
% dobs = bulk composition
% mnr = phases
% uc = uncertainty on the bulk composition
% phase_label = user input phase IDs (string)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% input data is in wt% with 14 species in the following order:
% 1-SiO2 (S)
% 2-TiO2
% 3-Al2O3 (A)
% 4-Cr2O3
% 5-FeO
% 6-MnO
% 7-MgO (M)
% 8-CaO (C)
% 9-Na2O
% 10-K2O
% 11-P2O5
% 12-NiO
% 13-H2O
% 14-Fe2O3

% oxide name will be updated as we remove or amalgamate oxides
oxname = {'SiO2', 'TiO2', 'Al2O3', 'Cr2O3', 'FeO', 'MnO', 'MgO', 'CaO',...
    'Na2O', 'K2O', 'P2O5', 'NiO', 'H2O', 'Fe2O3'};
ox = 1:length(oxname); %number index for oxides
molwt = [60.08 79.866 101.96 151.99 71.844 70.9374 40.3044 56.0774...
    61.9789 94.2 283.9 74.6928 18.02 159.69]; %molar weight for each oxide, g/mol

% amalgamate FeO and Fe2O3
[row,col]=size(mnr);
mnrT=zeros(row,col);
mnrT(:,1)=mnr(:,1);
for i=1:row
    combo=mnr(i,2:end)./molwt; %convert grams to mol for phases
    combo(5)=combo(5)+2*combo(14); %mol FeO = mole FeO + 2 * mol Fe2O3
    combo=combo(1:13).*molwt(1:13); %convert mol back to grams
    mnrT(i,2:14)=combo/sum(combo); %normalize to 1
end

dobs = dobs./molwt; %convert grams to mol for bulk
dobs(5)=dobs(5)+2*dobs(14); %mol FeO = mole FeO + 2 * mol Fe2O3
dobsm=dobs(1:13).*molwt(1:13); %convert mol back to grams
dobsm=dobsm/sum(dobsm); %normalize to 1

%propagate uncertainty on FeO and Fe2O3
uc(5) = molwt(5)*sqrt((uc(5)./molwt(5))^2 + (2*uc(14)./molwt(14))^2);
uc(14) = [];

clear mnr
mnr=mnrT;
dobs=dobsm;
Nphase=max(mnr(:,1)); % number of endmember phases

% At this point data is in wt fraction (sum = 1)
% with 13 species in the following order:
% 1-SiO2 (S)
% 2-TiO2
% 3-Al2O3 (A)
% 4-Cr2O3
% 5-FeO
% 6-MnO
% 7-MgO (M)
% 8-CaO (C)
% 9-Na2O
% 10-K2O
% 11-P2O5
% 12-NiO
% 13-H2O

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OKnorm % run OK-norm on composition

% at this point we have weight-% bulk (dobs) and endmember (mnr)
% compositions. We need to remove all zero columns from mnr and all zeroes
% from dobs, then rennormalize:
Ib=find(mnr(1,:)>0);
%must include Si (column index =2) for calculation
if ~any(Ib==2) == 1 %if 2 is not in Ib vector
    Ib = sort([Ib 2]); %add 2 to Ib vector and keep in sorted number order
    %this avoids code break when Si-free phase is in first row of phase matrix (mnr)
end

[nny, nnx]=size(mnr);
mnr2=zeros(nny,length(Ib));
for ui=1:length(Ib)
    mnr2(:,ui)=mnr(:,Ib(ui));
    if ui>1
        oxlabel(ui-1)=oxname(Ib(ui)-1);
    end
end
clear mnr

% at this point there might still be oxides with zero values that made it
% through the OK norm (e.g. K2O) - replace 0 by 0.0001
mnr2(mnr2==0)=0.0001; % just in case

% renormalize mnr
for ui=1:nny
    mnr2(ui,2:length(Ib))=mnr2(ui,2:length(Ib))./sum(mnr2(ui,2:length(Ib)));
end
mnr=mnr2;
uc=uc(dobs>0);
dobs=dobs(dobs>0);
dobs=dobs/sum(dobs);

% extract data on the endmembers from the files:
% G is the endmember matrix
% sG is the uncertainty matrix on the ilr of G (each column represents the
% standard deviation of the ilr of the composition of each phase)
covG=zeros(Nphase*(length(dobs)-1),Nphase*(length(dobs)-1));
G=zeros(length(dobs),Nphase);
sG=zeros(length(dobs)-1,Nphase);

stdG=zeros(length(dobs),Nphase);

for j=1:Nphase
    idx=find(mnr(:,1)==j);
    M=mnr(idx,2:end);
    [Nmes, Nel]=size(M);
    ivec=zeros(Nmes,Nel-1);
    for i=1:Nmes
        vec=M(i,:)/sum(M(i,:));
        ivec(i,:)=ilr(vec);
    end
    is=std(ivec);
    mn=ilrinv(mean(ivec));
    G(1:length(mn),j)=mn';
    sG(1:length(mn)-1,j)=is';
    
    if errortype==1
        covG(1+(j-1)*(Nel-1):j*(Nel-1),1+(j-1)*(Nel-1):j*(Nel-1))=cov(ivec);
        % standard error
    elseif errortype==2
        covG(1+(j-1)*(Nel-1):j*(Nel-1),1+(j-1)*(Nel-1):j*(Nel-1))=(1/Nmes)*cov(ivec);
        % standard error of the mean
    end
    
    stdG(:,j)=std(M)'; % contains standard dev on G in compo space, to assess shift in G vs. G_inf later
    
end

% the covariance matrix containing the uncertainties on the endmember
% compositions may be badly scaled, likely due to its off-diagonal
% coefficients. If that's the case, only its diagonal part is kept
if rcond(covG)<1e-15
    disp('WARNING - endmember covariance matrix badly conditioned - was reduced to its diagonal')
    covG=diag(diag(covG));
end


% renormalize dobs
dobs=dobs'/sum(dobs); % uncertainty vector on the ilr of dobs

% alternate computation of dobs uncertainty:
% draw Ndrawdobs random compositions of dobs, ilr them, extract stdev
[drawdobs]=draw_compos(Ndrawdobs,dobs',uc);
iddobs = zeros(Ndrawdobs,length(dobs)-1);
for i=1:Ndrawdobs 
    iddobs(i,:)=ilr(drawdobs(i,:)./sum(drawdobs(i,:))); 
end
sdobs=std(iddobs)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ACTUAL INVERSION ROUTINE
[m_inf, s_inf, am, SIG, G_inf, ub, lb, ms, d_inf,R,bounds]=lime(G,dobs,covG,sdobs,1,yn_iterate_on_endmembers,NEWT,phase_label);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

shiftG=(G_inf-G)./stdG; % diagnostic to see if endmember compositions have changed much

% OUTPUT DISPLAY

disp('------------------------------')
disp('INVERSION RESULTS')
disp('phase order')
disp(string(phase_label'))
disp('mean phase composition (wt %) and standard deviation (wt %)')
disp(100*mean(R)) %mean
disp(100*s_inf) %standard deviation (1 sigma)

disp('--------')
disp(['ERROR MEASURE USES SPECIFIED PERCENTILES: [' num2str(bounds([1 3])) '].'])
disp(['minus to ' num2str(bounds(1)) 'th percentile (wt %)'])
disp(100*(m_inf-lb))
disp('best fitting phase composition (wt%)')
disp(100*m_inf)
disp(['plus to ' num2str(bounds(3)) 'th percentile (wt %)'])
disp(100*(ub-m_inf))

disp('--------')
disp('oxide order')
disp(string(oxlabel))
disp('corresponding data prediction (wt %)')
disp(100*d_inf')
disp('... and true data (wt %)')
disp(100*dobs')
% disp('ilr-misfit')
% disp(ms)
disp('------------------------------')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% WRITE RESULTS TO OUTPUT FILE
if output_yn == 1 %if output on
    % m_inf = best fitting phase compo (mean)
    % s_inf = standard deviation
    % lb = lower bound
    % ub = upper bound
    % G = true endmember composition
    % shiftG = relative shift in endmember compos, in units of standard dev
    % G_inf = a posteriori endmember compos
    % dobs = true bulk
    % d_inf = predicted bulk
    % ms = ilr-misfit
    
    output = {'phase', string(phase_label');
        'mean', round(100*mean(R),4);
        'std dev (wt%)', round(100*s_inf,4);
        ['minus to ' num2str(bounds(1)) ' percentile (wt %)'], round(100*(m_inf-lb),4);
        'best fitting phase comp. (wt%)', round(100*m_inf,4);
        ['plus to ' num2str(bounds(3)) 'percentile (wt %)'], round(100*(ub-m_inf),4);
        ' ' ' ';
        'oxide order', string(oxlabel);
        'corresponding data prediction (wt%)', round(100*d_inf,4)';
        'true data (wt%)', round(100*dobs,4)';
        };
    
    [path, ifn, ext] = fileparts(filename{f}); %file info, fn = filename, ext = extension
    
    fn = [ifn '_LIME']; %append _LIME to input filename (without extension)
    ct = 0; %initiate "count" at 0 for loop below
    
    while exist(fn, 'dir') %if LIME folder with that filename already exists
        %modify name to make numbered copy instead of overwriting
        ct = ct+1; %find next number for copy
        fn = [ifn '_LIME (' num2str(ct) ')']; %new filename (copy #)
    end
    
    mkdir(fn) %make folder for output using modified filename (without extension)
    
    %Write output file to output folder
    %File type defined by name extension (ex: .txt, .csv, .xlsx)
    writecell(output, fullfile(fn, [ifn '_LIME_results.xlsx']), 'Sheet', 'Main Output') %command line output
    
    %     %If Excel input, can also append output as new sheet in input Excel file
    %     if contains(ext, '.xls') == 1 %if file extension is .xls, .xlsx, .xlsb
    %         writecell(output, filename{f}, 'Sheet', 'LIME RESULTS')
    %     end

    %Comment this out for speed if not interested in R output
    R_out = [phase_label'; num2cell(R)]; %create array of modeled phase abundances with column labels
    writecell(R_out, fullfile(fn, [ifn '_LIME_results.xlsx']), 'Sheet', 'Modeled abundances') %modeled abundances for histograms and stats
%     writecell(R_out, fullfile(fn, [ifn '_R_array.xlsx'])) %separate file for R array output

    copyfile(filename{f},fn) %copy input file used in calculation to output folder

    %Save results from PDF figure to file in output folder
    %File type defined by name extension (ex: .pdf, .jpg, .png, .tif)
    %exportgraphics(gcf,[ifn '.pdf']) %MATLAB 2020 function (crops automatically)
    set(gcf, 'PaperPosition', [0 -2 8 8]); %position plot, set width and height
    set(gcf, 'PaperSize', [8 4]); %crop printout to plot width and height
    
    saveas(gcf,fullfile(fn,[ifn '_LIME_figure.pdf'])) %save figure in output folder with input file name
else %no output
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assess convergence
ipha=am(:,end-(Nphase-2):end);
[Nit,junk]=size(ipha);
pha=zeros(Nit,Nphase);
for ui=1:Nit
    pha(ui,:)=ilrinv(ipha(ui,:));
end

if plot_cvg == 1 %if on, plot convergence figure
    figure
    plot(100*pha,'.')
    hold on
    plot(100*pha)
    grid on
    xlabel('iteration #','fontsize',15)
    ylabel('phase proportions (wt %)','fontsize',15)
    title('Convergence plot','fontsize',15)
    set(gca,'PlotBoxAspectRatio',[3 1 1])
    xlim([1 Nit])
end