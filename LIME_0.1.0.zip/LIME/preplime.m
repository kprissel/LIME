function [dobs, mnr, uc, ID] = preplime(varargin)
%preplime code to take data and configure it for LIME inputs
%see included "Inputs" folder for examples and TEMPLATE.xlsx

inputs = length(varargin); 

file = varargin{1}; %filename is always the first input
pct_err_bulk = varargin{2}; %uncertainty on bulk composition
%a value is fed in from lime_input.m but will be overwritten if values for
%each oxide are given in the input file using phase = "U" designation

comps = readcell(file); %load the file with phase and oxides
%include oxide names in headers, and have phase ID in column 1
headers = comps(1,2:end); %get the column headers (oxide names)
phaseID = comps(2:end,1);

data = cell2mat(comps(2:end,2:end)); %convert data matrix to numbers
data(data<0) = 0.0001; %turn any negative values into 0.0001 (could also do 0)

uidx = find(strcmp(phaseID,'U')==1); %find row for user input on bulk uncertainty
if any(uidx) %if there is a user input for uncertainty
    uc_in = data(uidx,:); %get the data from that row
    data(uidx,:) = []; %remove that row from data matrix
    phaseID(uidx) = [];
else
    uc_in = zeros(size(comps,2));
end

% Want data to be in this order:
oxides = {'SiO2', 'TiO2', 'Al2O3', 'Cr2O3', 'FeO', 'MnO', 'MgO', 'CaO',...
    'Na2O','K2O', 'P2O5', 'NiO', 'H2O', 'Fe2O3'};

limeOX = zeros(size(data,1),length(oxides)+1); %start off with lime input being a matrix of zeros 
% Will then go through and populate oxide columns that are in the data matrix,
%and will leave oxides that are not in the data matrix as columns of zeros
uc_out = zeros(1,length(oxides)); %reorder uncertainty columns too

for i = 1:length(oxides)
    index = find(contains(headers,oxides{i})); %find which data column the oxide corresponds to
    if ~isempty(index) == 1 %if a match was found for i-th oxide
    limeOX(:,i+1) = data(:,index); %make that data column the i-th column for limeOX
    %(pertaining to the current entry in oxides) which is i+1 in lime ox
    %because of the phase ID input in column 1
    uc_out(i) = uc_in(index);
    end
end
    
if inputs > 2
FeYN = varargin{3}; %third input indicates whether Fe should be included (=1) or not (=0)
if FeYN == 0 %if user has indicated do calculation without Fe 
    limeOX(:,6) = zeros; %turn FeO column to 0
    limeOX(:,14) = zeros; %turn Fe2O3 column to 0
end
end

bulk_index = find(strcmp(phaseID,'bulk')==1); %find the row with phaseID = bulk
dobs = limeOX(bulk_index,2:end); %bulk composition to load into LIME
limeOX(bulk_index,:) = []; %remove this row from phases after extracting bulk comp
phaseID(bulk_index) = [];

if any(uc_out) %if user input for bulk uncertainty (non zero)
    uc = uc_out; %user input for bulk uncertainty reordered with dobs
else
    uc = (pct_err_bulk/100)*dobs; %percent uncertainty on the bulk composition
end

uc = uc./100; %convert from wt% to frac

[num, ID] = findgroups(phaseID); %find unique phase entries
%num will be numbers for each group, ID will be text label

limeOX(:,1) = num; %phaseID in numbers
mnr = limeOX; %then have phase ID and phase comp input for LIME
end