function [ad, GG]=forwardilr(am,G)
% [ad, GG]=forwardilr(am,G) 
% computes the forward composition problem
% in ilr formulation, with uncertainties on the partitioning matrix
%
% input model vector contains:
% first the M ilr-compositions forming the columns of the partitioning
% matrix, then the actual ilr-phase distribution
[N, M]=size(G); 
GG=zeros(N,M);
for uu=1:M
    GG(:,uu)=ilrinv(am((uu-1)*(N-1)+1:uu*(N-1)));
end

m=ilrinv(am(M*(N-1)+1:M*N-1));
d=GG*m';
ad=ilr(d')';

end
