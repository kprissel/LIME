function y=ilrinv(x)
% y=ilrinv(x) 
% computes the inverse-isometric log-ratio transform
% from R(D-1) to the D-dimensional SD simplex (Egozcue et al., 2003)
D=length(x)+1;
U=zeros(D-1,D);
for i=1:D-1
    a=sqrt(i/(i+1));
    U(i,1:i)=a/i;
    U(i,i+1)=-a;
end
c=x*U;
y=clrinv(c);
end