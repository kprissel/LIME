function y=ilr(x)
% y=ilr(x) 
% computes the isometric log-ratio transform
% from the D-dimensional SD simplex to R(D-1) (Egozcue et al., 2003)
D=length(x);
U=zeros(D-1,D);
for i=1:D-1
    a=sqrt(i/(i+1));
    U(i,1:i)=a/i;
    U(i,i+1)=-a;
end
c=clr(x);
y=c*U';
end