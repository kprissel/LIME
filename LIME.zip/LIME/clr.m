function y=clr(x)
% y=clr(x) computes the centered log-ratio transform
% from the D-dimensional SD simplex to R(D) (Aitchison, 1986)
xD=geomean(x);
y=log(x/xD);
end