function y=clrinv(x)
% y=clrinv(x) computes the inverse centered log-ratio transform
% from R(D) to the D-dimensional SD simplex (Aitchison, 1986)
u=exp(x);
y=u/sum(u);
end