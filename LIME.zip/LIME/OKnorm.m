%% Olive-Krawczynski normalization (OK-norm)
% a procedure designed to eliminate / amalgamate oxides in a manner that
% facilitates solving the endmember mixing problem

%% STEP 0 - filter elements < detection threshold
dt=0.03/100; % detection threshold of 0.03%
mnr(mnr<dt)=0;
dobs(dobs<dt)=0;

%% STEP 1 - are there oxides missing from the bulk composition ?
% are some of the missing oxides reported in one or more phases at
% more than 5 mole % ?
Iabs=find(dobs==0); % absent from bulk
Ipres=find(dobs>0); % present in bulk
phase_abs=mnr(:,Iabs+1);
[Iinphase, Jinphase]=find(phase_abs>=0.05);
if isempty(Iinphase)==1 % none of the species absent from the bulk composition is present at more than 5% in any phase
    % then we can remove these oxides from the whole calculation
    [Itrace, Jtrace]=find(phase_abs<0.05); % these oxides are in trace amounts in some endmembers and should be ignored
    mnr(Itrace,Iabs+1)=0; % zero-out the oxides
    disp('Zero-ing oxides missing from the bulk composition')
else
    disp('an oxide absent from the bulk composition has been found in significant proportions in (at least) 1 phase')
    disp('This entire phase, and possibly others, should be removed from the calculation')
    disp('and / or data should be carefully checked.')
    disp('DO NOT TRUST THOSE RESULTS - SOMETHING IS WRONG !!')
end

%% STEP 2 - remove H2O, F, Cl and NiO % in this version just H2O and NiO
Ismall=find(strcmp(oxname,'NiO') | strcmp(oxname,'H2O'));
dobs(Ismall)=0;
mnr(:,Ismall+1)=0;
disp('removing NiO and H2O')

%% STEP 3 - amalgamate TiO2 and Al2O3 with SiO2 if needed
IAl=find(strcmp(oxname,'Al2O3'));
SiAl=0;
% does an endmember have zero Al2O3 ?
mnrAl=mnr(:,IAl+1); % Al-column
if isempty(find(mnrAl==0))==0 && isempty(find(mnrAl>0.194))==1 % some probe measurement(s) yielded zero Al2O3 and no other yielded more than 19.4% Al2O3
    % then amalgamate Al and Si
    disp('Amalgamating Si and Al')
    SiAl=1;
    oxname(1)=cellstr('SiO2-Al2O3');
    mnr(:,2)=mnr(:,2)+mnr(:,IAl+1);
    mnr(:,IAl+1)=0;
    dobs(1)=dobs(1)+dobs(IAl);
    uc(1)=sqrt(uc(1)^2+uc(IAl)^2);
    dobs(IAl)=0;
elseif isempty(find(mnrAl==0))==0 && isempty(find(mnrAl>0.194))==0 % some measurements yielded zero Al, others >19.4%
    % then substitute zeros by 0.0001
    disp('substituting zero Al by 0.01% Al')
    IzAl=find(mnrAl==0);
    mnr(IzAl,IAl+1)=0.0001;
end

% do the same for Ti
ITi=find(strcmp(oxname,'TiO2'));
mnrTi=mnr(:,ITi+1); % Ti-column
if isempty(find(mnrTi==0))==0 && isempty(find(mnrTi>0.08))==1 % some probe measurement(s) yielded zero Ti and no other yielded more than 8% Ti
    % then amalgamate Ti and Si
    disp('Amalgamating Si and Ti')
    if SiAl==1 % if we have already amalgamated Si and Al
        oxname(1)=cellstr('SiO2-Al2O3-TiO2');
    else
        oxname(1)=cellstr('SiO2-TiO2');
    end
    mnr(:,2)=mnr(:,2)+mnr(:,ITi+1);
    mnr(:,ITi+1)=0;
    dobs(1)=dobs(1)+dobs(ITi);
    uc(1)=sqrt(uc(1)^2+uc(ITi)^2);
    dobs(ITi)=0;
elseif isempty(find(mnrTi==0))==0 && isempty(find(mnrTi>0.08))==0 % some measurements yielded zero Ti, others >8%
    % then substitute zeros by 0.0001
    disp('substituting zero Ti by 0.01% Ti')
    IzTi=find(mnrTi==0);
    mnr(IzTi,ITi+1)=0.0001;
end

%% STEP 4 - dealing with Cr and Mn
ICr=find(strcmp(oxname,'Cr2O3'));
% does an endmember have zero Cr2O3 ?
mnrCr=mnr(:,ICr+1); % Cr-column
if isempty(find(mnrCr==0))==0 && isempty(find(mnrCr>0.04))==1 % some probe measurement(s) yielded zero Cr2O3 and no other yielded more than 4% Cr2O3
    % then zero out Cr
    disp('zero-ing Cr')
    mnr(:,ICr+1)=0;
    dobs(ICr)=0;
elseif isempty(find(mnrCr==0))==0 && isempty(find(mnrCr>0.04))==0 % some measurements yielded zero Cr, others >4%
    % then substitute zeros by 0.0001
    disp('substituting zero Cr by 0.01% Cr')
    IzCr=find(mnrCr==0);
    mnr(IzCr,ICr+1)=0.0001;
end

IMn=find(strcmp(oxname,'MnO'));
% does an endmember have zero MnO ?
mnrMn=mnr(:,IMn+1); % Mn-column
if isempty(find(mnrMn==0))==0 && isempty(find(mnrMn>0.04))==1 % some probe measurement(s) yielded zero MnO and no other yielded more than 4% MnO
    % then zero out Mn
    disp('zero-ing Mn')
    mnr(:,IMn+1)=0;
    dobs(IMn)=0;
elseif isempty(find(mnrMn==0))==0 && isempty(find(mnrMn>0.04))==0 % some measurements yielded zero Mn, others >4%
    % then substitute zeros by 0.0001
    disp('substituting zero Mn by 0.01% Mn')
    IzMn=find(mnrMn==0);
    mnr(IzMn,IMn+1)=0.0001;
end

%% STEP 5 - replace 0% MgO by 0.01% MgO if needed
IMg=7;
mnrMg=mnr(:,IMg+1); % MgO-column
IzMg=find(mnrMg==0);
if isempty(IzMg)==0
    disp('replacing zero MgO by 0.01% MgO')
    mnr(IzMg,IMg+1)=0.0001;
end

%% STEP 6 - amalgamate FeO with MgO if needed
IFe=find(strcmp(oxname,'FeO'));
MgFe=0;
% does an endmember have zero FeO ?
mnrFe=mnr(:,IFe+1); % FeO-column
if isempty(find(mnrFe==0))==0 % some probe measurement(s) yielded zero FeO
    % then amalgamate FeO and MgO
    disp('Amalgamating FeO and MgO')
    MgFe=1;
    oxname(7)=cellstr('MgO-FeO');
    mnr(:,8)=mnr(:,8)+mnr(:,IFe+1);
    mnr(:,IFe+1)=0;
    dobs(7)=dobs(7)+dobs(IFe);
    uc(7)=sqrt(uc(7)^2+uc(IFe)^2);
    dobs(IFe)=0;
end

%% STEP 7 - replace 0% CaO by 0.01% CaO if needed
ICa=find(strcmp(oxname,'CaO'));
mnrCa=mnr(:,ICa+1); % MgO-column
IzCa=find(mnrCa==0);
if isempty(IzCa)==0
    disp('replacing zero CaO by 0.01% CaO')
    mnr(IzCa,ICa+1)=0.0001;
end

%% STEP 8 - amalgamate Na2O and CaO if needed
INa=find(strcmp(oxname,'Na2O'));
mnrNa=mnr(:,INa+1);
CaNa=0;
if isempty(find(mnrNa==0))==0 % some probe measurement(s) yielded zero Na
    % then amalgamate Na2O and CaO
    disp('Amalgamating Na2O and CaO')
    CaNa=1;
    oxname(8)=cellstr('CaO-Na2O');
    mnr(:,9)=mnr(:,9)+mnr(:,INa+1);
    mnr(:,INa+1)=0;
    dobs(8)=dobs(8)+dobs(INa);
    uc(8)=sqrt(uc(8)^2+uc(INa)^2);
    dobs(INa)=0;
end

%% STEP 9 - replace 0% K2O by 0.01% K2O if needed
IK=find(strcmp(oxname,'K2O'));
mnrK=mnr(:,IK+1);

if isempty(find(mnrK==0))==0 && isempty(find(mnrK>0.06))==1 % some probe measurement(s) yielded zero K and no other yielded more than X% P
    % then zero out P
    disp('zero-ing K')
    mnr(:,IK+1)=0;
    dobs(IK)=0;
elseif isempty(find(mnrK==0))==0 && isempty(find(mnrK>0.06))==0 % some measurements yielded zero K, others >X%
    % then substitute zeros by 0.0001
    disp('substituting zero K by 0.01% K')
    IzK=find(mnrK==0);
    mnr(IzK,IK+1)=0.0001;
end

%% STEP 10 - replace 0% P2O5 by 0.01% if needed
IP=find(strcmp(oxname,'P2O5'));
% does an endmember have zero P ?
mnrP=mnr(:,IP+1); % P-column
if isempty(find(mnrP==0))==0 && isempty(find(mnrP>0.422))==1 % some probe measurement(s) yielded zero P and no other yielded more than 42.2% P
    % then zero out P
    disp('zero-ing P')
    mnr(:,IP+1)=0;
    dobs(IP)=0;
elseif isempty(find(mnrP==0))==0 && isempty(find(mnrP>0.422))==0 % some measurements yielded zero P, others >42.2%
    % then substitute zeros by 0.0001
    disp('substituting zero P by 0.01% P')
    IzP=find(mnrP==0);
    mnr(IzP,IP+1)=0.0001;
end