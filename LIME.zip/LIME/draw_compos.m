function [compos]=draw_compos(Nc,mean,std)

% [compos]=draw_compos(Nc,mean,std)
% J.-A. Olive
%
% draws Nc random compositions with specified mean and standard deviation (row-vectors)
% this function automatically eliminates values <0 and >100%
% Warning: "mean" must be a row vector
%
% example (copy paste the following into matlab terminal):
%
% mean=[46.64 1.47 13.76 3.75 3.28 0.12 5.45 7.58 4.25 2.8];
% std=[0.18 0.18 0.3 0.00001 0.00001 0.04 0.08 0.11 0.03 0.05];
% N=10;
% [compos]=draw_compos(Nc,mean,std)
%
% the output is a table where each line is a random composition
% following the specified distribution

k=0;
while k<Nc
    c=mean+std.*randn(1,length(mean));
    if isempty(find(c<0))==1 && isempty(find(c>100))==1
        k=k+1;
        compos(k,:)=c;
    end
end
    