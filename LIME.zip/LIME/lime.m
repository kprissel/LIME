function [m_inf, s_inf, am, SIG, G_inf, ub, lb, ms, d_inf,R,bounds,R1sig]=lime(G,dobs,covG,sdobs,ynplot,yn_iterate_on_endmembers,NEWT,phase_label)
%
% J.A. Olive, Fall 2009––April. 2012
% K. Prissel, 2020
% LIME - Logratio-Inversion of Mixed Endmembers
%
% "this is the core of the reactor"
% Quasi-Newton algorithm for estimating the phase distribution (m_inf)
% and the partitioning matrix G that best explains a bulk composition (dobs).
% Based on section 3.2.3 of Tarantola 2005
% http://www.ipgp.fr/~tarantola/Files/Professional/Books/InverseProblemTheory.pdf

% NUMERICAL PARAMETERS
Nit=NEWT.Nit; % number of iterations of the Newton algorithm
step=NEWT.step; % elementary step in ilr-model space

[N, M]=size(G); % nbr of components, nbr of phases.
ad=ilr(dobs'); % ilr-transform bulk composition

% a-priori phase distribution
m0=(1/M)*ones(M,1); % initial guess: equal proportions of each phase
amm0=ilr(m0');
am0=zeros(M*N-1,1);

for uu=1:M
    co=G(:,uu);
    aco=ilr(co');
    am0((uu-1)*(N-1)+1:uu*(N-1))=aco;
end
am0(M*(N-1)+1:M*N-1)=amm0;

Cd=diag(sdobs.^2); % covariance matrix on the data in ilr-space
sig_am0=NEWT.sig_am0; % (large) uncertainties on a-priori model in ilr-space 
Cm=covG;
for uv=M*(N-1)+1:M*N-1
    Cm(uv,uv)=sig_am0^2;
end

am(1,:)=am0;

for p=1:Nit
    mu=NEWT.mu;
    
    J=zeros(N-1,M*N-2);
    % computing the ilr-Jacobian dilr(di)/dilr(mj) at current model am(p,:)
    % using centered finite-difference
    
    for j=1:M*N-1
        
        % centered finite difference approx, using discrete step "step"
        current=am(p,:)';
        currentplus=current;
        currentminus=current;
        currentplus(j)=currentplus(j)+step/2;
        currentminus(j)=currentminus(j)-step/2;
        amplus=forwardilr(currentplus',G);
        amminus=forwardilr(currentminus',G);
        
        for i=1:N-1
            dd=amplus(i)-amminus(i);
            J(i,j)=dd/step; % approximate Jacobian
        end
        
    end
    
    
    % this prevents any adjustment to the end-member compositions
    % but could be removed if one wants to treat these as parameters
    blocker=0*ones(size(am0));
    blocker(end-(M-2):end)=1;
    blocker=blocker';
    if yn_iterate_on_endmembers==1
        blocker=1;
    end
    
    % 1 step of quasi-Newton algorithm
    [adtst, GG]=forwardilr(am(p,:),G);
    am(p+1,:)=am(p,:)-blocker.*(mu*(J'*Cd^-1*J+Cm^-1)^-1*(J'*Cd^-1*(adtst-ad')+Cm^-1*(am(p,:)'-am0)))';
    
end

Jinf=J; % final Jacobian
Cpost=Cm-Cm'*Jinf'*(Jinf*Cm*Jinf'+Cd)^-1*Jinf*Cm; % a-posteriori covariance matrix
% Cpost is a measure of uncertainty on the best fitting model, but in ilr-space
% we need to find a way to translate this into composition space

G_inf=GG;
am_inf=am(Nit,:);
m_inf=ilrinv(am_inf(M*(N-1)+1:M*N-1)); % inverse-ilr the best-fitting composition
d_inf=G_inf*m_inf';

% draw compositions from the posterior distribution to construct pdfs
Ndraw=NEWT.Ndraw;

% extract the parameters of the gaussian posterior distribution in ilr
% space:
SIGr=Cpost(end-(M-2):end,end-(M-2):end);
% due to numerical errors, SIG may not be exactly positive definite
% so we reduce it to its symmetric part
SIG=(SIGr+SIGr')/2;

% draw many random compositions from the posterior distribution
MU=am_inf(M*(N-1)+1:M*N-1);
RR = mvnrnd(MU,SIG,Ndraw);
%% JAO ADDED 11/10/23
Rf = zeros(Ndraw,1);
for j=1:Ndraw
    Rf(j)=mvnpdf(RR(j,:),MU,SIG)./mvnpdf(MU,MU,SIG);
end
LT1SIG = Rf>exp(-0.5); % flag the compositions within 1-sigma of mean
%%
R=zeros(Ndraw,M);
datapred=zeros(Ndraw,N);
for k=1:Ndraw
    R(k,:)=ilrinv(RR(k,:));
    vrac=R(k,:);
    datapred(k,:)=G_inf*vrac'; 
end
s_inf=std(R);

%% JAO ADDED 11/10/23
R1sig = R(LT1SIG,:); 
% R1sig is a table of randomly drawn compositions that fall within 1-sigma
% of the mean in ilr-space. All we have to do now is find the min-max for
% each component
% disp('ilr-space 1-sigma range (%):')
% disp(min(R1sig)*100)
% disp(max(R1sig)*100)
% disp('----')

%% Plot formatting
% RGB colors for lines in figure (add more if >7 phases)
% col = [72 60 70
%     60 110 113
%     112 174 110
%     190 238 98
%     244 116 59]./255;

col = [51 160 44
    31 120 180
    178 223 138
    166 206 227
    100 100 100
    100 100 100
    100 100 100]./255;

linesty = {'-' '-' '-' '-' '-' ':' '-.'};

lb=zeros(1,length(R(1,:)));
ub=lb;

figure
hold on
box on

for ui=1:length(R(1,:))
    
    [freq, co]=hist(100*R(:,ui),100);
    NORM=sum(freq(1:end-1).*diff(co));
    if ynplot==1
        p(ui) = plot(co,freq/NORM, '-k','color', col(ui,:),'LineStyle',linesty{ui},'linewidth',2);
        xlim([0 100])
        xlabel('Phase abundance (wt.%)')
        set(gca,'PlotBoxAspectRatio',[3 1 1])
        set(gca,'YTick',[])
    end
    
    %pr = prctile(R(:,ui), [25 50 75]); % 25th and 75th percentiles
    if length(NEWT.error_measure)==1
        if NEWT.error_measure==1
            bounds = [15.9 50 84.1]; % 15.9th and 84.1th percentiles; if distribution is gaussian this amounts to 1-sigma
        elseif NEWT.error_measure==2
            bounds = [2.3 50 97.7]; % 2.3 and 97.7 percentiles; if distribution is gaussian this amounts to 2-sigma
        end
    elseif length(NEWT.error_measure)==2 %two percentile values are given as inputs
        bounds = [NEWT.error_measure(1) 50 NEWT.error_measure(2)];
    else
        disp('error measure not implemented-- defaulting to 1-sigma')
        bounds = [15.9 50 84.1];
    end
    
    pr = prctile(R(:,ui), bounds); %get the percentiles using the defined bounds

    lb(ui)=pr(1); % lower bound
    ub(ui)=pr(3); % upper bound
end

    set(gca, 'FontSize', 16, 'LineWidth', 2)
    lg = legend(phase_label, 'Location', 'eastoutside'); %edit legend names to be user input phase names
    title(lg, 'Phase')
    set(gcf,'color','w')
    %grid on

bulk_pred=ilr(d_inf');
bulk_real=ilr(dobs');
ms=sqrt(sum((bulk_pred-bulk_real).^2));